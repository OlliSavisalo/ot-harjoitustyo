# Tuntikirjanpito

| Päivä | Aika | Tehdyt työt  |
| :----:|:-----| :-----|
|  8.11 |  2   | Sovelluksen ideoiminen, sovelluksen rakenteen suunnittelu  |
| 10.11 |  3   | Vaatimusmäärittelyn tekeminen ja tuntikirjanpidon aloitus  |
| 16.11 |  2   | Sovelluksen rakenteen hiomista |
| 17.11 |  4   | Sovelluksen perusosien koodaamista ja testien tekemistä |
|       |      |  |
|       |      |  |
|       |      |  |
|       |      |  |
|       |      |  |
|       |      |  |
|       |      |  |
| yht   | 5    | | 
