import java.util.*;
/**
 *
 * @author ollisavi
 */
public class Main {

    public static void main(String[] args) {
        Solitaire play = new Solitaire();
        play.startNewGame();
    }
    
}
